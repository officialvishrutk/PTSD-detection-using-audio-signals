import os
from flask import Flask, render_template, request, redirect
from werkzeug.utils import secure_filename
import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
from fastai.learner import load_learner

app = Flask(__name__)

UPLOAD_FOLDER = "E:/pervasive project/Upload_folder"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load the FastAI learner from the .pkl file
learn = load_learner(r"C:\Users\itsvi\Downloads\speech (2).pkl")

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser might
        # submit an empty file part without a filename.
        if file.filename == '':
            return redirect(request.url)
        if file:
            # Process the file here or send it to the Jupyter Notebook
            # For demonstration, we'll just print the file name
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            convert_to_mel_spectrogram(file_path)

            print(f'File uploaded: {file.filename}')

            # Get the path to the Mel spectrogram
            mel_spectrogram_path = os.path.splitext(file_path)[0] + '_mel_spectrogram.jpg'

            # Perform FastAI prediction
            pred_class, pred_idx, outputs = learn.predict(mel_spectrogram_path)
            # Print the predicted class and its probability
            print("Predicted Class:", pred_class)
            print("Probability:", outputs[pred_idx].item())

            if pred_class == 'non_stressed' and outputs[pred_idx].item() > 0.6:
                return render_template('non_stressed_exercises.html')
            elif pred_class == 'non_stressed':
                return render_template('non_stressed_hospitals.html')
            elif pred_class == 'stressed':
                return render_template('stressed_health_center.html')

            return f'File uploaded, converted to Mel Spectrogram, and predicted. Predicted Class: {pred_class}, Probability: {outputs[pred_idx].item()}'
    return

def convert_to_mel_spectrogram(file_path):
    # Load audio file
    audio, sr = librosa.load(file_path)
    # Compute Mel Spectrogram
    mel_spectrogram = librosa.feature.melspectrogram(y=audio, sr=sr)
    log_mel_spectrogram = librosa.power_to_db(mel_spectrogram, ref=np.max)
    # Save mel spectrogram as an image file with the correct file extension
    output_file_path = os.path.splitext(file_path)[0] + '_mel_spectrogram.jpg'
    librosa.display.specshow(log_mel_spectrogram, sr=sr, x_axis='time', y_axis='mel')
    plt.savefig(output_file_path, bbox_inches='tight', pad_inches=0)
    plt.close()
    print(f'Mel spectrogram saved as {output_file_path}')

if __name__ == '__main__':
    app.run(debug=True)
